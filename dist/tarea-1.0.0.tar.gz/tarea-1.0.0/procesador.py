from tkinter import * 
from tkinter import ttk
from modelo import Aplicacion


ventana=Tk()
app=Aplicacion(ventana)
ventana.mainloop()