from distutils.core import setup
setup(
name = 'tarea',
version = '1.0.0',
py_modules = ['procesador'],
author = 'hfpython',
author_email = 'juanbarretor@gmail.com',
url = 'fascinaweb.com',
description = 'Es una prueba de uso',
packages=['modulo_base_datos', 'modulo_validacion'],
)